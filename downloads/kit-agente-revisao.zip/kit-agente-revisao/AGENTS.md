# Agente de revisão de literatura

Este arquivo orienta um agente de código (Claude Code, Codex ou similar) a conduzir uma revisão rápida de literatura sobre os PDFs desta pasta, com rastreabilidade total entre fonte e conclusão.

## Estrutura da pasta

- `pergunta.md`: a pergunta da revisão, escrita pela equipe.
- `criterios.md`: critérios de inclusão e exclusão, escritos pela equipe.
- `pdfs/`: os textos completos dos estudos.
- `saida/`: tudo o que o agente produz. O agente não altera nada fora desta pasta.

## Regras que nunca mudam

1. Trabalhe só com os PDFs de `pdfs/`. Não cite, não busque e não acrescente estudos.
2. Toda informação extraída vem com a página do PDF. Se não estiver no documento, escreva "não informado".
3. Aplique os critérios de `criterios.md` como estão escritos. Se algum for ambíguo para um estudo, registre "dúvida" e explique; não decida por conta própria.
4. Não arredonde, não converta e não complete números. Copie como estão no estudo.
5. Marque como [inferência] tudo o que não estiver dito explicitamente em algum PDF.
6. Estudo descritivo (survey, entrevista, caso) nunca é prova de efeito.
7. Registre se cada resultado é da média ou de um subgrupo e quando o desfecho foi medido.
8. Não apague nem altere os PDFs, `pergunta.md` ou `criterios.md`.

## Fluxo

Execute na ordem e pare ao fim de cada etapa, mostrando o resultado e esperando o "ok" do usuário.

1. Leitura: extraia o texto de cada PDF (por exemplo, com pdftotext ou PyMuPDF), guardando a numeração de páginas. Liste os PDFs lidos e o número de páginas. Se algum PDF não tiver texto extraível, avise.
2. Triagem: gere `saida/triagem.csv` com as colunas arquivo, estudo, decisao (entra, nao_entra, duvida), criterio, trecho, pagina.
3. Extração: para os estudos que entraram, gere `saida/extracao.csv` com as colunas estudo, versao, pergunta, desenho, amostra_contexto, desfecho_quando, efeito, media_ou_subgrupo, limitacoes, exemplo_pratico, paginas.
4. Síntese: gere `saida/sintese.md`, de até uma página, que responda a `pergunta.md`. Cada afirmação termina com o estudo entre parênteses. Diga quando um achado depende de um único estudo.
5. Verificação automática: para cada número e cada citação de `saida/sintese.md` e `saida/extracao.csv`, procure o trecho no texto do PDF, na página indicada. Gere `saida/verificacao.md` com uma tabela: afirmação, estudo, página, trecho encontrado, situação (confere, página errada, não encontrado). Tudo o que não for "confere" vai para o topo do arquivo.
6. Fechamento: mostre ao usuário o resumo da verificação e a lista "Para conferir", com os pontos de menor segurança.

## O que a equipe confere antes de usar

- Todas as decisões "duvida" e todas as exclusões da triagem.
- Cada linha de `saida/verificacao.md` que não for "confere".
- Uma amostra de números da extração, abrindo o PDF na página indicada.
