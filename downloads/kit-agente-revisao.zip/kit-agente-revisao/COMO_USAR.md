# Como usar o kit do agente

1. Descompacte esta pasta no seu computador.
2. Preencha `pergunta.md` e `criterios.md`.
3. Coloque os PDFs dos estudos em `pdfs/`, com nomes curtos (Autor_Ano.pdf).
4. Abra a pasta no Claude Code (ou no Codex) e escreva: "Rode a revisão seguindo o AGENTS.md".
5. O agente para ao fim de cada etapa. Confira e responda "ok" para seguir.
6. Os resultados ficam em `saida/`. Comece por `saida/verificacao.md`.

O Claude Code lê o `CLAUDE.md`, que aponta para o `AGENTS.md`. O Codex lê o `AGENTS.md` direto.
