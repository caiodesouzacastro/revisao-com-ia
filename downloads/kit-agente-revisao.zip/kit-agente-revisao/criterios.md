# Critérios de inclusão e exclusão

## Entram
- Tipo de estudo:
- População:
- Intervenção ou exposição:
- Desfecho:
- Período:
- Idioma:

## Não entram
-

## Definições de termos ambíguos
- Termo: definição. Caso de fronteira: entra ou não entra.
