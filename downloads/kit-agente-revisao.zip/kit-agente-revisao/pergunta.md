# Pergunta da revisão

Escreva aqui a pergunta principal, em uma frase.

Pergunta:

Tipo de pergunta (efeito ou descrição):

População:

Intervenção ou exposição:

Comparação:

Desfecho:

Perguntas secundárias (opcional):
