---
name: revisao-de-literatura
description: Conduz revisão rápida de literatura e síntese de evidências com rastreabilidade, da pergunta à verificação final, exigindo página em cada informação e separando estudos de efeito, revisões e estudos descritivos. Use quando pedirem revisão de literatura, síntese de evidências, triagem ou extração de estudos, ou conferência de uma síntese contra os estudos.
---

# Revisão de literatura com rastreabilidade

Esta skill conduz uma revisão rápida em sete etapas. O objetivo não é ir rápido a qualquer custo: é chegar a uma síntese em que cada frase pode ser conferida no estudo de origem.

## Regras que nunca mudam

1. Nunca cite estudo de memória. Toda referência vem de um documento anexado, de uma lista colada pelo usuário ou de uma busca feita numa base. Se pedirem "me dê estudos sobre X" sem documentos e sem busca, monte a estratégia de busca e explique por quê.
2. Toda informação extraída vem com a página. Se não estiver no documento, escreva [não encontrado].
3. Marque como [inferência] tudo o que não estiver dito explicitamente em algum documento.
4. Aplique os critérios de inclusão como foram escritos. Se algum for ambíguo (por exemplo, "professor" inclui tutor?), pare e pergunte. Nunca amplie um critério em silêncio.
5. Responda à pergunta feita. Se os documentos só respondem a uma pergunta vizinha, diga isso logo no início.
6. Não arredonde, não converta e não complete números.
7. Estudo descritivo (survey, entrevista, caso) nunca é prova de efeito.
8. Diga se cada resultado é da média ou de um subgrupo e se o desfecho é de curto prazo ou final.
9. Quando um achado depender de um único estudo, diga isso.

## Quem decide o quê

Você faz o trabalho mecânico e deixa o julgamento visível. Não decida questões de mérito: aponte e pergunte.
- Equipe: decide a pergunta, registra os critérios, faz a busca nas bases, confere exclusões e números.
- Especialista no tema: decide casos de fronteira, avalia a qualidade do desenho de cada estudo, revisa as mensagens principais e aprova a versão final.
Ao fim de cada etapa, diga em uma linha o que a equipe precisa conferir e se a etapa pede o especialista.

## Etapas

Pare ao fim de cada etapa e mostre o resultado para o usuário conferir antes de seguir.

### 1. Pergunta
Feche a pergunta em uma frase. Identifique população, intervenção ou exposição, comparação e desfecho. Decida com o usuário se a pergunta é de efeito (exige estudos com comparação) ou de descrição (aceita surveys e qualitativos). Liste termos ambíguos.

### 2. Critérios
Proponha critérios de inclusão e exclusão: tipo de estudo, população, intervenção, desfecho, período, idioma, tipo de publicação. Para cada termo ambíguo, uma definição e um caso de fronteira.

### 3. Busca
Proponha strings booleanas (inglês e português), bases (ERIC, Scopus, Web of Science, SciELO, Google Acadêmico) e repositórios de avaliação (EEF, J-PAL, 3ie, What Works Clearinghouse, OCDE, Banco Mundial). Se houver ferramenta de busca disponível na sessão, use-a e registre data e string. Não invente estudos.

### 4. Triagem
Para cada título e resumo: entra, não entra ou dúvida, com o trecho que justifica. Use o modelo de registro em `references/tabela-extracao.md`. Tudo o que for dúvida vai para o usuário.

### 5. Extração
Com os textos completos anexados, preencha a tabela de `references/tabela-extracao.md`. Uma linha por estudo. Página em toda célula com conteúdo. Se a versão lida for working paper, registre. Depois, reúna para o especialista, com página, as informações de qualidade: como os grupos foram formados, amostra e perdas, como e quando o desfecho foi medido, pré-registro, revisão por pares, limitações declaradas. Não dê nota e não diga se o estudo é bom; esse julgamento é do especialista.

### 6. Síntese
Até uma página, organizada por dimensão. Cada afirmação termina com o estudo de origem entre parênteses e deixa claro o desenho do estudo, média ou subgrupo, e prazo do desfecho. Separe o que é efeito do que é uso ou percepção.

### 7. Verificação
Confira a síntese frase por frase contra os documentos, mostrando trecho literal e página. Classifique cada frase: sustentada, parcialmente sustentada, não sustentada, inferência não marcada. Use `references/checklist.md` e `references/erros-comuns.md`. Recomende ao usuário repetir esta etapa num chat novo, sem o histórico da síntese, e lembre que a versão final é aprovada pelo especialista.

## Ao terminar qualquer entrega

Feche com uma seção curta "Para conferir", com os pontos de menor segurança (números, páginas, decisões de triagem de fronteira e inferências) e o que pede revisão do especialista.

## Dados

Se aparecerem dados pessoais ou sensíveis, avise e sugira anonimizar antes de seguir.
