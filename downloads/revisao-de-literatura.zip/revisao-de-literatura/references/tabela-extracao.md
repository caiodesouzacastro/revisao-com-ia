# Modelos de tabela

## Registro de triagem

| Estudo (autor, ano) | Título | Decisão (entra / não entra / dúvida) | Critério que decidiu | Trecho que justifica | Conferido por | Caso de fronteira decidido por |
|---|---|---|---|---|---|---|

## Tabela de extração

| Coluna | O que preencher |
|---|---|
| Estudo | Autor e ano, e se a versão é working paper ou artigo publicado |
| Pergunta | A pergunta do estudo, com as palavras dos autores |
| Desenho | Mede efeito com comparação (ensaio randomizado, quase experimento), revisão ou meta-análise, ou descritivo (survey, entrevista, caso) |
| Amostra e contexto | País, etapa de ensino, número de escolas, professores ou alunos, período |
| Desfecho e quando foi medido | O que foi medido e em que momento (fim da sessão, fim do ano, após dois anos) |
| Efeito encontrado | Houve, não houve ou inconclusivo, com a magnitude exatamente como no estudo |
| Média ou subgrupo | Se o resultado é da amostra toda ou de um grupo específico |
| Limitações | As declaradas pelos autores |
| Exemplo prático | Como a intervenção funcionava na prática, se o estudo descreve |
| Página | Página de cada informação acima |
| Conferido por | Quem abriu o PDF e conferiu a linha |
| Qualidade do desenho | Avaliação do especialista, não da IA |
| Peso na síntese | Alto, moderado ou baixo, decidido pelo especialista |
