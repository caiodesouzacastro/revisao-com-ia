# Erros comuns ao usar IA em revisão de literatura

Use esta lista na verificação. Cada item diz como o erro aparece e como pegá-lo.

- Referência inventada: autor, ano e revista plausíveis para um estudo que não existe. Pegue buscando o título no Google Acadêmico, no Crossref ou no OpenAlex.
- Estudo real, achado deformado: a referência existe, mas o achado atribuído não é o do estudo (um efeito negativo descrito como "não necessariamente positivo"). Pegue lendo o resumo e a tabela de resultados.
- Detalhe errado com cara de precisão: a resposta acerta quase tudo e erra o desenho do experimento, o nível da randomização ou a amostra. Pegue conferindo a seção de método, não só os números.
- Contexto trocado: país, etapa de ensino ou população diferentes dos do estudo. Pegue na seção de dados.
- Pergunta trocada: a resposta trata de uma pergunta vizinha (aprendizagem dos alunos quando a pergunta era sobre o trabalho do professor). Pegue relendo a pergunta antes de ler a resposta.
- Critério ampliado sem aviso: a triagem inclui casos que o critério escrito não cobre (tutores quando o critério dizia professores). Pegue conferindo todas as decisões de fronteira.
- Número sem fonte: um número plausível que não está no documento. Pegue procurando o número exato no PDF.
- Survey tratado como efeito: percentual de uso ou percepção apresentado como prova de que algo funciona. Pegue olhando o desenho de cada estudo citado.
- Subgrupo apresentado como média: efeito que só aparece num grupo descrito como efeito geral. Pegue procurando "entre", "among", "subgroup", "heterogeneity" na tabela de resultados.
- Desfecho de curto prazo lido como resultado final: ganho medido no fim de uma sessão apresentado como aprendizagem. Pegue verificando quando o desfecho foi medido.
- Resumo de ferramenta de busca usado como síntese: o parágrafo gerado pela ferramenta vira a conclusão sem que ninguém leia os estudos.
- Versão trocada: números do working paper citados como se fossem do artigo publicado, ou o contrário.
- Pergunta que embute a resposta: perguntar "por que X funciona" leva a IA a procurar razões, não a testar se funciona. Pegue reformulando a pergunta de forma neutra.
